
chrome.runtime.onInstalled.addListener(() => {
  console.log("onInstalled triggered — extension installed or updated");
});

chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (details.url.includes("/v1/epic/action/activated")) {
      console.log("Web Worker Request Detected:", details);
      // You can also send this data to your content script or perform other actions
      if (details.requestBody && details.requestBody.raw) {
        const decoder = new TextDecoder("utf-8");
        const bodyText = decoder.decode(details.requestBody.raw[0].bytes);
        console.log("Decoded Body Text:", bodyText);
        try {
          const decodedBody = JSON.parse(bodyText);
    
          // Check if screenname matches the desired value
          if (decodedBody.screenName === "Client.Detail|0") {
            console.log("Screenname matched, sending message to content script");
    
            // Send a message to content script to inject the button
            chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
              chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                files: ["injectButton.js"]  // Load the shared inject.js script
              });
            });
          }
        } catch (error) {
          console.error("Error decoding JSON:", error);
        }

      }
    }
  },
  { urls: ["https://*.appliedepic.com/*"] },
  ["requestBody"]
);

