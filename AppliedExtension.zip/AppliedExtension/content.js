(function () {


    function isTargetPage() {
        const hostMatch = window.location.hostname === 'gnpin01.appliedepic.com';
        const hash = window.location.hash; 
        const queryString = hash.includes('?') ? hash.split('?')[1] : '';
        const params = new URLSearchParams(queryString);
        return hostMatch && params.get('program') === 'Accounts';
    }
	
	
	
    function tryInject() {
        if (isTargetPage()) 
			console.log("here we inject button on load")
    }
	
	const originalOpen = XMLHttpRequest.prototype.open;
	const originalSend = XMLHttpRequest.prototype.send;

	XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
		console.log("we have arrived");
	  if (url.includes("/v1/epic/action/activated")) {
		console.log("🧳 Intercepted XMLHttpRequest:", method, url);
  
		// Capture the request body and other details
		const requestBody = this._requestBody; // if any data is set manually before calling send()
  
		this.addEventListener('load', function() {
		  console.log("🎯 XMLHttpRequest response:", this.responseText);
		  // Optionally, send response data back to service worker
		  chrome.runtime.sendMessage({
			type: "xhrRequestIntercepted",
			url: url,
			response: this.responseText,
			requestBody: requestBody
		  });
		});
	  }
  
	  return originalOpen.apply(this, arguments);
	};

	XMLHttpRequest.prototype.send = function (body) {
		// Only watch POST requests to the specific endpoint
		if (
		this._method === "POST" &&
		this._url.includes("/v1/epic/action/activated")
		) {
		try {
			if (typeof body === "string") {
			const parsedBody = JSON.parse(body);
			if (parsedBody.screenName === "Client.Detail|0") {
				console.log("🎯 Matched XHR Request:", parsedBody);
				// You can send this to the background script or trigger any action
				// chrome.runtime.sendMessage({ type: "epic-screen-activated", data: parsedBody });
			}
			}
		} catch (e) {
			console.warn("Failed to parse XHR body", e);
		}
		}
		return originalSend.apply(this, arguments);
  };
    tryInject();
    window.addEventListener('hashchange', tryInject);
})();
