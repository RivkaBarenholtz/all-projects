

(async () => {
    const sd = await getSubdomain();
    globalThis.subdomain = sd; 
  })();



if (!document.getElementById('font-style')) {

    const style = document.createElement('style');
    style.id='font-style';
        style.textContent = `
        @font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url('${chrome.runtime.getURL('fonts/inter-v18-latin-regular.woff2')}') format('woff2');
        }

        * {
            font-family: 'Inter';
        }

        @font-face {
            font-family: "Font Awesome 6 Free";
            font-display: block;
            font-weight: 400;
            src: url('${chrome.runtime.getURL('/webfonts/fa-brands-400.woff2')}') format("woff2"),
                url(${chrome.runtime.getURL("webfonts/fa-solid-400.ttf")}) format("truetype");
            }
        }

        @font-face {
            font-family: "Font Awesome 6 Free";
            font-display: block;
            font-weight: 900;
            src: url(${chrome.runtime.getURL("webfonts/fa-solid-900.woff2")}) format("woff2"),
                url(${chrome.runtime.getURL("webfonts/fa-solid-900.ttf")}) format("truetype");
            }

            @font-face {
            font-family: "Font Awesome 6 Free";
            font-display: block;
            font-weight: 400;
            src: url(${chrome.runtime.getURL("webfonts/fa-regular-400.woff2")}) format("woff2"),
                url(${chrome.runtime.getURL("webfonts/fa-regular-400.ttf")}) format("truetype");
            }

            @font-face {
            font-family: "Font Awesome 6 Free";
            font-display: block;
            src: url(${chrome.runtime.getURL("webfonts/fa-solid-900.woff2")}) format("woff2"),
                url(${chrome.runtime.getURL("webfonts/fa-solid-900.ttf")}) format("truetype");
            }

            @font-face {
            font-family: "Font Awesome 6 Free";
            font-display: block;
            src: url(${chrome.runtime.getURL("webfonts/fa-brands-400.woff2")}) format("woff2"),
                url(${chrome.runtime.getURL("webfonts/fa-brands-400.ttf")}) format("truetype");
            }

            @font-face {
            font-family: "Font Awesome 6 Free";
            font-display: block;
            src: url(${chrome.runtime.getURL("webfonts/fa-regular-400.woff2")}) format("woff2"),
                url(${chrome.runtime.getURL("webfonts/fa-regular-400.ttf")}) format("truetype");
            unicode-range: u+f003,u+f006,u+f014,u+f016-f017,u+f01a-f01b,u+f01d,u+f022,u+f03e,u+f044,u+f046,u+f05c-f05d,u+f06e,u+f070,u+f087-f088,u+f08a,u+f094,u+f096-f097,u+f09d,u+f0a0,u+f0a2,u+f0a4-f0a7,u+f0c5,u+f0c7,u+f0e5-f0e6,u+f0eb,u+f0f6-f0f8,u+f10c,u+f114-f115,u+f118-f11a,u+f11c-f11d,u+f133,u+f147,u+f14e,u+f150-f152,u+f185-f186,u+f18e,u+f190-f192,u+f196,u+f1c1-f1c9,u+f1d9,u+f1db,u+f1e3,u+f1ea,u+f1f7,u+f1f9,u+f20a,u+f247-f248,u+f24a,u+f24d,u+f255-f25b,u+f25d,u+f271-f274,u+f278,u+f27b,u+f28c,u+f28e,u+f29c,u+f2b5,u+f2b7,u+f2ba,u+f2bc,u+f2be,u+f2c0-f2c1,u+f2c3,u+f2d0,u+f2d2,u+f2d4,u+f2dc;
            }

            @font-face {
            font-family: "Font Awesome 6 Free";
            font-display: block;
            src: url(${chrome.runtime.getURL("webfonts/fa-v4compatibility.woff2")}) format("woff2"),
                url(${chrome.runtime.getURL("webfonts/fa-v4compatibility.ttf")}) format("truetype");
            unicode-range: u+f041,u+f047,u+f065-f066,u+f07d-f07e,u+f080,u+f08b,u+f08e,u+f090,u+f09a,u+f0ac,u+f0ae,u+f0b2,u+f0d0,u+f0d6,u+f0e4,u+f0ec,u+f10a-f10b,u+f123,u+f13e,u+f148-f149,u+f14c,u+f156,u+f15e,u+f160-f161,u+f163,u+f175-f178,u+f195,u+f1f8,u+f219,u+f27a;
            }

        `;

// Append to shadow root
document.head.appendChild(style);
}
globalThis.invoiceData = globalThis.invoiceData || [];


function handleChangeClientSurcharge(newSurcharge)
{
    globalThis.invoiceData.forEach(element => {
        if(document.getElementById(`customSurcharge-${element.id}`).value == globalThis.Surcharge)
        {
            handleChangeSurcharge(newSurcharge.currentTarget.value, element.id);
        }
    });

    globalThis.Surcharge = newSurcharge.currentTarget.value; 
}

function handleChangeSurcharge (newSurcharge, invoiceID)
{
    //let invoice = invoiceData.find((i)=>i.id== invoiceID)
    
    document.getElementById(`customSurcharge-${invoiceID}`).value = newSurcharge; 
    // let swallowamount = (globalThis.vendorSurcharge * invoice.Balance) - (newSurcharge/100 * invoice.Balance);
    // document.getElementById(`tdSwallow-${invoiceID}`).innerHTML = `$${swallowamount.toFixed(2)}`; 
    
}

function ApplyButtonClicksToApplyChangeButtons(isReverting, shadow)
{
    if (isReverting)
    {
        shadow.getElementById("applyFutureOnlyBtn").removeEventListener("click", SaveFutureItemsOnly);
        shadow.getElementById("applyAllOpenBtn").removeEventListener("click", SaveAllOpenInvoices);
        
        shadow.getElementById("applyFutureOnlyBtn").addEventListener("click", RevertOnlyFutureInvoices)
        shadow.getElementById("applyAllOpenBtn").addEventListener("click", RevertAllOpenInvoices);
        

    }
    else
    {
        shadow.getElementById("applyFutureOnlyBtn").addEventListener("click", SaveFutureItemsOnly);
        shadow.getElementById("applyAllOpenBtn").addEventListener("click", SaveAllOpenInvoices);
        
        shadow.getElementById("applyFutureOnlyBtn").removeEventListener("click", RevertOnlyFutureInvoices)
        shadow.getElementById("applyAllOpenBtn").removeEventListener("click", RevertAllOpenInvoices);
        
    }
}

function toggleViewClientSurcharge(val)
{
    const shadowHost = document.getElementById('customModalOverlay');
    const shadow = shadowHost.shadowRoot; 
    
    if(val)
    {
        shadow.getElementById("customClientSurchargeDiv").style.display="flex";
        shadow.getElementById("accountDefaultSurchargeRow").style.display="none";

        
    }
    else 
    {
        shadow.getElementById("customClientSurchargeDiv").style.display="none";
        shadow.getElementById("modalTitle").innerHTML= "Revert Account Surcharge To System Default";
        shadow.getElementById("updateOptionsModal").style.display = "flex";
        ApplyButtonClicksToApplyChangeButtons(!val, shadow);
    }
    
}

function waitForDivWithFallback(timeout = 10000) {
   const observer = new MutationObserver(() => {
        const targetDiv = document.querySelector('div[data-automation-id="fraAccount"]');
        if (targetDiv) {
            console.log("found target div")
            injectButton(targetDiv);
            observer.disconnect();
            clearTimeout(fallbackTimer);
        }
        else {
            console.log("target div not found")
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    const fallbackTimer = setTimeout(() => {
        observer.disconnect();
        injectButton(document.body); // fallback to body
    }, timeout);
}




function injectButton(targetParent) {
    if (document.getElementById('custom-button')) return;

    const button = document.createElement('button');
    button.id = 'custom-button';
    button.textContent = 'Generate Payment Link';
    Object.assign(button.style, {
        position: 'absolute',
        margin: '10px',
        padding: '10px 16px',
        backgroundColor: '#007bff',
        color: '#fff',
        border: 'none',
        borderRadius: '6px',
        cursor: 'pointer',
        fontSize: '14px',
        top: '0',
        right: '0'
    });

    button.onclick = () => showModal();

    (targetParent || document.body).appendChild(button);
}

function getCurrentAccountID(){
    const hash = window.location.hash; // "#/?program=Accounts&tabGroup=...&data=..."
    const hashUrl = new URL('https://dummy.com' + hash.slice(1)); // slice(1) removes the '#' 
    const params = new URLSearchParams(hashUrl.search);

   const dataParam = params.get("data");

    if (dataParam) {
        try {
            const dataObj = JSON.parse(decodeURIComponent(dataParam));
            
            const aValue = dataObj.A;
            return aValue;

            
        } catch (err) {
            console.error("Failed to parse 'data' parameter:", err);
        }
    } else {
        console.warn("'data' parameter not found in URL");
    }
}

async function getAndPopulateOpenInvoices(shadow)
{
    const getInvoiceUrl =`https://${globalThis.subdomain}.instechpay.co/pay/get-open-invoices`;
    const body = {
        AccountId : getCurrentAccountID(), 
        LookupCode: getAccountLookupCode()
    }

    const response  = await  fetch(getInvoiceUrl, {
        method: 'POST',
        body: JSON.stringify(body),
        headers: { 'Content-Type': 'application/json' }
    })

    const data = await response.json();
    const tbody = shadow.querySelector("#invoiceTable tbody");

    data.forEach((item, index) => {
        //const swallowedAmount  =(item.Balance * globalThis.vendorSurcharge) - (item.Balance *  item.Surcharge )
        item["id"]= index;
        const row = document.createElement("tr");

        const isCustom = vendorSurcharge!==item.Surcharge;

        row.dataset['id'] = index;
        
        
        
        row.innerHTML = `
            <td class="invoice-number">
               
            </td>
            <td class="money-value">$${item.InvoiceTotal.toFixed(2)}</td>
            <td class="money-value" >$${item.Balance.toFixed(2)}</td>
            <td class="surcharge-cell">
                ${GetInvoiceSurchargeHtml(false, item)}
            </td>
            
            <td> 
                <button 
                    class="btn btn-icon link-btn tooltip"  
                    data-tooltip="Copy Payment Link"
                    data-id="${item.id}"
                >
                    <i class="fas fa-link"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
        ApplyCustomToRow(row, item.AppliedEpicInvoiceNumber, isCustom)
    });
    
    globalThis.invoiceData = data;

    

    
}

function ApplyCustomToRow(row , invoiceNumber , isCustom)
{
    if(isCustom) row.classList.add("custom-surcharge-row");
    if(!isCustom) row.classList.remove("custom-surcharge-row");

    row.querySelectorAll(".invoice-number").forEach(td =>
    {
        td.innerHTML= `
            ${isCustom ? '<span class="invoice-badge invoice-badge-custom">Custom</span>' : ''}
            ${invoiceNumber}`
    })

}
function GenerateButtonClicksForInvoiceRow()
{
    const shadowHost = document.getElementById('customModalOverlay');
    const shadow = shadowHost.shadowRoot; 

    shadow.querySelectorAll('.link-btn').forEach(link => {
        link.addEventListener('click', (e) => {
        e.preventDefault();
        const id = e.currentTarget.dataset.id;
        CopyInvoiceLink( id);
        });
    });

    shadow.querySelectorAll('.btn-edit-invoice').forEach(button => {
        button.addEventListener('click', (e) => {
        e.preventDefault();
        EditInvoiceSurcharge(e.currentTarget, true); 
        });
    });

    shadow.querySelectorAll('.btn-reset').forEach(button => {
        button.addEventListener('click', (e) => {
        e.preventDefault();
        RevertInvoiceSurcharge(e.currentTarget, true); 
        });
    });

    shadow.querySelectorAll('.btn-cancel-edit-invoice').forEach(button => {
        button.addEventListener('click', (e) => {
        e.preventDefault();
        EditInvoiceSurcharge(e.currentTarget, false); 
        });
    });

    shadow.querySelectorAll('.btn-save-invoice').forEach(button => {
        button.addEventListener('click', (e) => {
        e.preventDefault();
        SaveCustomInvoiceSurcharge(e.currentTarget); 
        });
    });
}

function EditInvoiceSurcharge(button, isEdit ){
    const td = button.closest('td');
    const tr = button.closest('tr');
    const id = tr.dataset.id;
    const invoice = invoiceData.find(i=> i.id==id);
    
    td.innerHTML = GetInvoiceSurchargeHtml(isEdit, invoice );
    if( isEdit)  tr.classList.add('editing-row');
    if( !isEdit)  tr.classList.remove('editing-row');

    

    GenerateButtonClicksForInvoiceRow();
   
}

async function SaveCustomInvoiceSurcharge(button )
{
    const td = button.closest('td');
    const tr = button.closest('tr');
    const id = tr.dataset.id;
    const invoice = invoiceData.find(i=> i.id==id);
    const input = td.querySelector('input');
    invoice.Surcharge = input.value/100; 
    await save([{ClientLookupCode: getAccountLookupCode(), SurchargeAmount: invoice.Surcharge, InvoiceNumber: invoice.AppliedEpicInvoiceNumber}])
    tr.classList.remove('editing-row');
    td.innerHTML= GetInvoiceSurchargeHtml(false , invoice); 
    GenerateButtonClicksForInvoiceRow();
    ApplyCustomToRow(tr, invoice.AppliedEpicInvoiceNumber, invoice.Surcharge!==globalThis.vendorSurcharge);
}

async function RevertInvoiceSurcharge(button  )
{
    const td = button.closest('td');
    const tr = button.closest('tr');
    const id = tr.dataset.id;
    const invoice = invoiceData.find(i=> i.id==id);
    invoice.Surcharge = globalThis.vendorSurcharge; 
    await save([{ClientLookupCode: getAccountLookupCode(), SurchargeAmount: invoice.Surcharge, InvoiceNumber: invoice.AppliedEpicInvoiceNumber}])
    td.innerHTML= GetInvoiceSurchargeHtml(false , invoice); 
    GenerateButtonClicksForInvoiceRow();
    ApplyCustomToRow(tr, invoice.AppliedEpicInvoiceNumber, false);
}

function GetInvoiceSurchargeHtml(isEditting, invoice )
{
    const isCustom = invoice.Surcharge !== globalThis.vendorSurcharge; 
    const colorstring = isCustom?'var(--surcharge-color-custom)':'var(--surcharge-color-default)'

    return isEditting?  `<div class="input-group">
    <div class="input-wrapper">
        <input type="number" step="0.01" class="surcharge-input" data-original-surcharge="${invoice.Surcharge.toFixed(2)}" value="${(invoice.Surcharge *100 ).toFixed(2)}" min="0" max="3.5">
    </div>
    <span class="percent-sign">%</span>
    <div class="btn-group">
        <button class="btn btn-icon btn-save tooltip btn-save-invoice" data-tooltip="Save Surcharge"><i class="fas fa-check"></i></button>
        <button class="btn btn-icon btn-cancel tooltip btn-cancel-edit-invoice"  data-tooltip="Cancel Edit"><i class="fas fa-times"></i></button>
    </div>
    </div>`:
    `<span class="surcharge-value"  style="color:${colorstring};">${invoice.Surcharge * 100}%</span>
    <div class="btn-group">
        <button class="btn btn-icon btn-edit tooltip btn-edit-invoice" data-action="edit-row" data-tooltip="Edit Surcharge"><i class="fas fa-edit"></i></button> 
        ${isCustom ? 
            `<button 
                class="btn btn-icon btn-reset tooltip" 
                data-action="reset-row" 
                data-tooltip="Reset to Account Default (${vendorSurcharge}%)
            ">
                <i class="fas fa-redo-alt"></i>
            </button>` : ''
        }

    </div>`
}

async function SaveFutureItemsOnly ()
{
    
    await SaveAll();
    showModal();
}

async function SaveAllOpenInvoices()
{
    let items = [];
    const shadowHost = document.getElementById('customModalOverlay');
    const shadow = shadowHost.shadowRoot; 
    
    const clientSurchargeAmount = shadow.getElementById("inputCustomSurcharge").value;
    let clientSurcharge = getSurchargeItem (-1 , clientSurchargeAmount/100)
   
    if(clientSurcharge == false ) return; 
    items.push(clientSurcharge);
    globalThis.invoiceData.forEach((a)=>
    {
        let invoiceSurcharge =  { ClientLookupCode: clientSurcharge.ClientLookupCode, SurchargeAmount: clientSurcharge.SurchargeAmount, InvoiceNumber: a.AppliedEpicInvoiceNumber}
        items.push(invoiceSurcharge);            
    } );

    await save(items);
    showModal(); 
}

async function RevertAllOpenInvoices(){
    let items = [];
    let clientSurcharge = getSurchargeItem ( -1 , vendorSurcharge )
    if(clientSurcharge == false ) return; 
    items.push(clientSurcharge);
    globalThis.invoiceData.forEach((a)=>
    {
        let invoiceSurcharge =  getSurchargeItem ( a.id , vendorSurcharge)
        items.push(invoiceSurcharge);            
    } );
   await save(items);
   showModal();
}
async function RevertOnlyFutureInvoices()
{
    const shadowHost = document.getElementById('customModalOverlay');
    const shadow = shadowHost.shadowRoot; 
    
    shadow.getElementById("inputCustomSurcharge").value= globalThis.vendorSurcharge * 100 ; 
    await SaveAll(); 
    showModal()
}

async function CreateModal()
{
    const modal = document.createElement('div');
    modal.id = 'customModalOverlay';
    // const htmlFontSize = getComputedStyle(document.documentElement).fontSize;
    // modal.style.fontSize = htmlFontSize;
    
    document.body.appendChild(modal);

    const shadow = modal.attachShadow({ mode: 'open' });

    const cssUrl = chrome.runtime.getURL('styles/fonts.css');
    const response = await fetch(cssUrl);
    const cssText = await response.text();

    const style = document.createElement('style');
    style.textContent = cssText;
    shadow.appendChild(style);

    const fontAwesomeCssUrl = chrome.runtime.getURL('styles/all.min.css');
    const fontAwesomeCssResponse = await fetch(fontAwesomeCssUrl);
    const fontAwesomeCssText = await fontAwesomeCssResponse.text();

    const fontAwesomeStyle = document.createElement('style');
    fontAwesomeStyle.textContent = fontAwesomeCssText;
    shadow.appendChild(fontAwesomeStyle);

    modal.style.cssText = `
          position: fixed;
          top: 0; left: 0;
          width: 100vw;
          height: 100vh;
          background-color: rgba(0,0,0,0.5);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 10000;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        `;

    return shadow;
}

async function showModal() {
    const clientLookupCode = getAccountLookupCode();
    let shadow = null ; 
    const modal = document.getElementById('customModalOverlay'); 
    
    if (!modal)
    {
        shadow = await  CreateModal()
    }
    else 
    {
        const shadowHost = document.getElementById('customModalOverlay');
        shadowHost.style.display= 'flex'; 
        shadow = shadowHost.shadowRoot; 
    }
   
    const surchargResponse  = await fetch(`https://${globalThis.subdomain}.instechpay.co/pay/get-surcharge`, {
        method: 'POST',
        body: JSON.stringify({ ClientLookupCode: clientLookupCode }),
        headers: { 'Content-Type': 'application/json' }
    })

    
    const result  = await  surchargResponse.json();

    
    globalThis.Surcharge= result.surcharge * 100 ; 
    globalThis.vendorSurcharge = result.vendorSurcharge ; 


    const divInsert =  document.createElement('div');
    divInsert.id = "divInsert";
    divInsert.innerHTML = `
    <div class="body-class">
     <div class="header">
        <div class="logo">
            <i class="fas fa-shield-alt"></i>
            INSURETECH
        </div>
         <button id="closeCustomModal" class="cancel-out"  >
            <i class="fas fa-times"></i>
        </button>
    </div>
    <div class="container" >
        <div id="loader" class="loading-div" >
            <div class="spinner"></div> 
            <p> Loading...</p>
        </div>
        <div class="card">
            <div class="card-header">
                <h3>
                    <i class="fas fa-building"></i>
                    Client Information
                    <span class="client-badge">${clientLookupCode}</span>
                </h3>
            </div>
            <div class="card-body">
               
                <div class="surcharge-row" id="accountDefaultSurchargeRow">
                    <label>Account Default Surcharge</label>
                    <div class="surcharge-value">
                        <span id="accountDefaultSurcharge">${result.surcharge * 100}%</span>
                        <span id="defaultBadge" class="system-default-badge">System Default</span>
                        <span id="customBadge" > <span class="custom-badge"> Custom</span>
                            <button class="btn btn-icon btn-edit tooltip" id="editCustomAccountSurchargeBtn" data-tooltip="Edit Custom Rate">
                                <i class="fas fa-edit"></i>
                            </button>
                        </span>
                        
                    </div>
                </div>

                 <div class="surcharge-row" id="customClientSurchargeDiv" style="display: none;">
                    <label>Edit Account Surcharge</label>
                    <div class="input-group">
                        <div class="input-wrapper">
                            <input type="number" step="0.01" id="inputCustomSurcharge" value="${result.surcharge * 100}" min="0" max="3.5">
                        </div>
                        <span class="percent-sign">%</span>
                        <div class="btn-group">
                            <button class="btn btn-icon btn-save" id="saveCustomAccountSurchargeBtn" data-tooltip="Save">
                                <i class="fas fa-check"></i>
                            </button>
                            <button class="btn btn-icon btn-cancel" id="cancelCustomAccountSurchargeBtn" data-tooltip="Cancel">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                </div>

               <div class="switch-container">
                    <label class="switch" for="cbChangeClientSurcharge">
                        <input type="checkbox" id="cbChangeClientSurcharge">
                        <span class="slider"></span>
                    </label>
                    <span class="switch-label">Set custom surcharge for this account</span>
                </div>

                
            </div>

        </div>
        <div class="card">
            <div class="card-header">
                <h3>
                    <i class="fas fa-file-invoice-dollar"></i>
                    Invoice List
                </h3>
            </div>
            <div class="table-container">
                <table class="table" id="invoiceTable">
                    <thead>
                        <tr>
                            <th>Invoice Number</th>
                            <th>Invoice Amount</th>
                            <th>Balance</th>
                            <th>Surcharge</th>
                            <th>Pay Link</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div> 
        </div>
    </div> 

    <div id="updateOptionsModal" class="modal-backdrop" style="display: none;">
        <div class="modal-panel">
            <div class="modal-header">
                <i class="fas fa-question-circle"></i>
                <h4 id="modalTitle">Apply Custom Account Surcharge To:</h4>
            </div>
            <div class="modal-body">
                <div class="modal-options">
                    <button id="applyFutureOnlyBtn" class="modal-btn">
                        <i class="fas fa-arrow-right"></i>
                        <div>
                            <strong>Future Invoices Only</strong>
                            <div style="font-size: 0.8125rem; color: var(--text-secondary); font-weight: normal; margin-top: 0.25rem;">
                                Existing unedited invoices keep their current surcharge
                            </div>
                        </div>
                    </button>
                    <button id="applyAllOpenBtn" class="modal-btn">
                        <i class="fas fa-sync-alt"></i>
                        <div>
                            <strong>All Open Invoices</strong>
                            <div style="font-size: 0.8125rem; color: var(--text-secondary); font-weight: normal; margin-top: 0.25rem;">
                                Overrides all existing invoices
                            </div>
                        </div>
                    </button>
                    <button class="modal-btn cancel" id="cancelApplyBtn">
                        <i class="fas fa-ban"></i>
                        <span>Cancel</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    

   
    <div style="display: flex; justify-content: center; gap: 15px; margin-bottom: 10px;">

    </div>
    <div id="surchargeModalError" style="color:red;font-size:11px" >  </div>
    </div>
`;
    
    if(shadow.getElementById("divInsert")) shadow.removeChild(shadow.getElementById("divInsert"));
    shadow.appendChild(divInsert); 

    await getAndPopulateOpenInvoices(shadow); 

    
    shadow.getElementById('closeCustomModal').addEventListener('click', () => {
        document.getElementById('customModalOverlay').style.display = 'none';
    });

    //shadow.getElementById('inputCustomSurcharge').addEventListener('change', (val)=> handleChangeClientSurcharge(val));
    shadow.getElementById('cbChangeClientSurcharge').addEventListener('change', (val)=> toggleViewClientSurcharge(val.target.checked));
    shadow.getElementById('saveCustomAccountSurchargeBtn').addEventListener('click', () => { shadow.getElementById("updateOptionsModal").style.display= "flex" ; ApplyButtonClicksToApplyChangeButtons(false, shadow); })
    shadow.getElementById('cancelCustomAccountSurchargeBtn').addEventListener('click', () => { 
        toggleEditMode(false, shadow);
        
    })
    shadow.getElementById('editCustomAccountSurchargeBtn').addEventListener('click', () => { 
        toggleEditMode(true, shadow);

    })
    
    shadow.getElementById('cancelApplyBtn').addEventListener('click', () => { shadow.getElementById("updateOptionsModal").style.display= "none";
        shadow.getElementById("cbChangeClientSurcharge").checked= true;
     })

    toggleSurchargeBadge(result.surcharge,result.vendorSurcharge, shadow)
    GenerateButtonClicksForInvoiceRow(); 
    shadow.getElementById("loader").style.display="none";
}

function toggleEditMode(
    isEdit , shadow
){
    if(isEdit)
    {
        shadow.getElementById("customClientSurchargeDiv").style.display="flex";
        shadow.getElementById("accountDefaultSurchargeRow").style.display="none";
    }
    else
    {
        shadow.getElementById("customClientSurchargeDiv").style.display="none";
        shadow.getElementById("accountDefaultSurchargeRow").style.display="flex";
    }
}
function toggleSurchargeBadge(clientSurcharge, vendorSurcharge, shadow)
{
    const isClientCustom = clientSurcharge !== vendorSurcharge;
    shadow.getElementById("cbChangeClientSurcharge").checked= isClientCustom; 
    
    if(isClientCustom)
    {
        shadow.getElementById('defaultBadge').style.display="none";
        shadow.getElementById('customBadge').style.display="flex";
        

    }
    else
    {
        shadow.getElementById('defaultBadge').style.display="flex";
        shadow.getElementById('customBadge').style.display="none";
    }
}

function getAccountLookupCode() {
    const container = document.querySelector('[data-automation-id="streLookupCode"]');
    if (container) {
        const asiElement = container.querySelector('asi-string-edit .string-edit');
        if (asiElement) {
            const value = asiElement.getAttribute('data-value');
            console.log('Value:', value);
            return value;
        } else {
            console.log('asi-string-edit or .string-edit not found.');
            return "";
        }
    } else {
        console.log('Container not found.');
        return "";
    }
}
function validate(customSurcharge) {

    const shadowHost = document.getElementById('customModalOverlay');
    const shadow = shadowHost.shadowRoot; 
    
    const errorDiv = shadow.getElementById("surchargeModalError");
    errorDiv.innerHTML = "";
    if (customSurcharge == "") {
        errorDiv.innerHTML = "Missing custom surcharge."
        return false;
    }
    else {
        const customSurchargeNum = Number(customSurcharge);
        if (isNaN(customSurchargeNum) || customSurchargeNum < 0 || customSurchargeNum > 3.5) {
            errorDiv.innerHTML = "Invalid custom sucharge."
            return false;
        }
    }
    return true;
}
async function getSubdomain() {
    const id = "conflokldehmgojnpaelmlgdodjimame"
    const isdevelop = id == chrome.runtime.id;
    if (isdevelop) {
        return "ins-dev";
       }
    else {
        const hostname = window.location.hostname; 
        const parts = hostname.split('.');
        const epicsubdomain = parts.length > 2 ? parts[0] : null;
        const response = await fetch(`https://ins-dev.instechpay.co/pay/get-subdomain?subdomain=${epicsubdomain}`);
        const result = await  response.text(); 
        return result ; 
    }
    
}




function CopyInvoiceLink( invoiceID){
    //save([getSurchargeItem( invoiceID, customSurcharge)]);
    
    const invoice= globalThis.invoiceData.find(invoice => invoice.id == invoiceID)
    const lookupCode = getAccountLookupCode();
    let url = `${globalThis.subdomain}.instechpay.co/app/?account=${lookupCode}&amount=${invoice.Balance}&invoiceid=${invoice.AppliedEpicInvoiceNumber}`;
    navigator.clipboard.writeText(url).then(() => {
        console.log("Copied!");
        alert("Success ...link copied")
        });
        
    
}
function getSurchargeItem(invoiceID, customSurcharge)
{

    
    
    if (validate(customSurcharge)) {
        const lookupCode = getAccountLookupCode();
        let surchargeItem = { ClientLookupCode: lookupCode, SurchargeAmount: Number(customSurcharge)  }
        if (invoiceID > -1 )
        {
            const invoiceNumber = globalThis.invoiceData.find(invoice => invoice.id == invoiceID).AppliedEpicInvoiceNumber;
            surchargeItem['InvoiceNumber']= invoiceNumber;
        }
        return surchargeItem; 
    }
    return false; 

}

async function SaveAll()
{
    let items = [];
    const shadowHost = document.getElementById('customModalOverlay');
    const shadow = shadowHost.shadowRoot; 
    
    const clientSurchargeAmount = shadow.getElementById("inputCustomSurcharge").value;
    let clientSurcharge = getSurchargeItem (-1 , clientSurchargeAmount/ 100)
    if(clientSurcharge == false ) return; 
    items.push(clientSurcharge);
    globalThis.invoiceData.forEach((a)=>
    {
        let invoiceSurcharge = getSurchargeItem( a.id , a.Surcharge)
        if(invoiceSurcharge == false ) return; 
        items.push(invoiceSurcharge) ; 
    }  );
    await save(items);
    //document.getElementById('customModalOverlay').style.display = 'none';
    //showSuccessModal();
          
}

async function save(body) {
    
   var response = await  fetch(`https://${globalThis.subdomain}.instechpay.co/pay/save-surcharge`, {
        method: "POST",
        body: JSON.stringify(body),
        headers: { 'Content-Type': 'application/json' }

    })
        
    if (!response.ok) {
        throw new Error('Network response was not ok');
    }
    return "Success";
        
        
}

function showSuccessModal() {
    if (document.getElementById('customSuccessModal')) {
        document.getElementById('customSuccessModal').style.display = 'flex';
        return;
    }
    const modal = document.createElement('div');
    modal.id = 'customSuccessModal';
    modal.style.cssText = `
			position: fixed;
			top: 0; left: 0;
			width: 100vw;
			height: 100vh;
			background-color:background-color: rgba(0,0,0,0.2);
			display: flex;
			justify-content: center;
			align-items: center;
			z-index: 10000;
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		  `;
    modal.innerHTML = `
		  <div style="
			 background: rgb(255, 255, 255);;
			  padding: 30px 40px;
			  width: 100%;
			  max-width: 200px;
			  border-radius: 16px;
			  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
			  text-align: center;
			  color:green;
			  font-size:15px
		  ">
		  	Success updating client surcharge information! 
			  <button id="closeSuccessModal" style="
					
					padding: 6px 10px;
					font-size: 16px;
					border: 1px solid #ccc;
					border-radius: 6px;
					text-align: center;
				">OK</button>

		  </div>`

    document.body.appendChild(modal);
    document.getElementById('closeSuccessModal').addEventListener('click', () => {
        document.getElementById('customSuccessModal').style.display = 'none';
    });
}



waitForDivWithFallback();

