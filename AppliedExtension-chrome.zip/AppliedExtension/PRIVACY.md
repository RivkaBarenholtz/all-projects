# Privacy Policy for AppliedExtension

Effective date: May 29, 2025

This browser extension does not collect, store, or share any personal information.

## What We Collect

This extension may access:
- The current tab or URL (only to provide its core features)
- We use this data to determine if and which client you are of Insuretech so that you can save payment data properly
No data is transmitted to any external server.

## Third-Party Services

If the extension connects to external APIs (e.g., Gmail, payment processors), those services have their own privacy policies.

## Updates

We may update this policy. Any changes will be committed to this file in the GitHub repository.

## Contact

If you have questions, contact us at: [rbarenholtz@instechpay.com]
